/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
 
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import com.mycompany.mockexam.EstateAgent; 
/**
 *
 * @author ntokozomtsali
 */
public class EstateAgentTest {
 //This test ensures the method can accumulate multiple sales figures and return the correct total.
    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
     // ARRANGE - Set up test data
    EstateAgent agent = new EstateAgent();
    double[] joeSales = {800000, 1500000, 2000000};
    double expectedTotal = 4300000;
    
    // ACT - Call the method we're testing
    double actualTotal = agent.EstateAgentSales(joeSales);
    
    
    // ASSERT - Check if actual equals expected
    assertEquals(expectedTotal, actualTotal, 0.01);   
    }
    
    // This test ensures the commission calculation formula is correct: Commission = Total Sales × 0.02
    @Test
    public void CalculateTotalCommission_ReturnsCommission() {
      //ARRANGE    
    EstateAgent agent = new EstateAgent();
    double totalSales = 4300000;  // Joe's total
    double expectedCommission = 86000;  // 2% of 4300000
    
    // ACT
    double actualCommission = agent.EstateAgentCommission(totalSales);
    
    // ASSERT
    assertEquals(expectedCommission, actualCommission, 0.01);
    }
    
    //This test ensures the method properly compares two sales totals and returns the correct agent index.
    @Test
    public void TopAgent_ReturnsTopPosition() {
          EstateAgent agent = new EstateAgent();
    double[] totalSales = {4300000, 3500000};  // Joe, Jane
    int expectedTopAgent = 0;  // Joe (index 0) has more
    
    // ACT
    int actualTopAgent = agent.TopEstateAgent(totalSales);
    
    // ASSERT
    assertEquals(expectedTopAgent, actualTopAgent); 
    }
}   
