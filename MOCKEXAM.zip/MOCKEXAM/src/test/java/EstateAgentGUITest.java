package com.mycompany.mockexam;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;


public class EstateAgentGUITest {
    
    /**
     * This test verifies the core calculation is accurate:
     * Commission = Property Price × (Commission Percentage ÷ 100)
     */
    @Test
    public void CalculateCommission_CalculatedSuccessfully() {
        // ARRANGE: Set up the test data
        // Created a new EstateAgent object for testing
        EstateAgentQ2 agent = new EstateAgentQ2();
        
        // Define test inputs as strings (as they come from GUI form fields)
        String propertyPrice = "800000";
        String commissionPercentage = "10";
        
        // Define the expected result
        double expectedCommission = 80000.0;
        
        // ACT: Execute the method being tested
        double actualCommission = agent.CalculateCommission(propertyPrice, commissionPercentage);
        
        // ASSERT: Verify the result is correct
        // The third parameter (0.01) allows for small floating-point differences
        assertEquals(expectedCommission, actualCommission, 0.01,
                     "Commission should be 10% of 800,000 = 80,000");
    }
    
    /**
     * This test ensures the method fails gracefully when given bad data,
     * preventing silent calculation errors with garbage input.
     */
    @Test
    public void CalculateCommission_CalculatedUnSuccessfully() {
        // ARRANGE: Set up test data with invalid input
        EstateAgentQ2 agent = new EstateAgentQ2();
        
        // Invalid input: text instead of a number
        String propertyPrice = "invalid";
        String commissionPercentage = "10";
        
        // ACT & ASSERT: Verify that NumberFormatException is thrown
        // when the method tries to convert "invalid" to a double
        assertThrows(NumberFormatException.class, () -> {
            // This method call should throw an exception
            agent.CalculateCommission(propertyPrice, commissionPercentage);
        }, "Should throw NumberFormatException for non-numeric input");
    }
    
    /**
     * Test Scenario: All form fields contain valid data
     * - Agent Location: "Cape Town" (not empty)
     * - Agent Name: "Joe Bloggs" (not empty)
     * - Property Price: "800000" (greater than 0)
     * - Commission Percentage: "10" (greater than 0)
     * 
     * Expected Outcome: ValidateData returns true (all validations pass)
     * 
     * This test verifies that valid data passes all validation rules.
     */
    @Test
    public void ValidateData_ValidInput() {
        // ARRANGE: Create an EstateAgent and Data object
        EstateAgentQ2 agent = new EstateAgentQ2();
        Data testData = new Data();
        
        // Set all form fields with valid data
        testData.setAgentLocation("Cape Town");      // Not empty
        testData.setAgentName("Joe Bloggs");         // Not empty
        testData.setPropertyPrice("800000");         // > 0
        testData.setCommissionPercentage("10");      // > 0
        
        // ACT: Call the validation method
        boolean isValid = agent.ValidateData(testData);
        
        // ASSERT: Verify validation returns true
        assertTrue(isValid, "Valid data should return true");
    }
    
    /**
     * Additional Test: ValidateData_EmptyLocation
     * 
     * Tests that ValidateData correctly rejects form data when 
     * the Agent Location field is empty.
     * 
     * Validation Rule Being Tested: Location cannot be empty
     * 
     * This ensures the validation catches missing location input.
     */
    @Test
    public void ValidateData_EmptyLocation() {
        // ARRANGE: Create data with empty location
        EstateAgentQ2 agent = new EstateAgentQ2();
        Data testData = new Data();
        
        // Empty location field (fails validation rule)
        testData.setAgentLocation("");
        testData.setAgentName("Joe Bloggs");
        testData.setPropertyPrice("800000");
        testData.setCommissionPercentage("10");
        
        // ACT: Validate the data
        boolean isValid = agent.ValidateData(testData);
        
        // ASSERT: Verify validation fails for empty location
        assertFalse(isValid, "Empty location should fail validation");
    }
    
    /**
     * Additional Test: ValidateData_InvalidPrice
     * 
     * Tests that ValidateData correctly rejects form data when 
     * the Property Price is zero or negative.
     * 
     * Validation Rule Being Tested: Property Price must be > 0
     * 
     * This ensures prices cannot be zero or negative.
     */
    @Test
    public void ValidateData_InvalidPrice() {
        // ARRANGE: Create data with invalid price
        EstateAgentQ2 agent = new EstateAgentQ2();
        Data testData = new Data();
        
        testData.setAgentLocation("Cape Town");
        testData.setAgentName("Joe Bloggs");
        testData.setPropertyPrice("0");              // Invalid: must be > 0
        testData.setCommissionPercentage("10");
        
        // ACT: Validate the data
        boolean isValid = agent.ValidateData(testData);
        
        // ASSERT: Verify validation fails for zero price
        assertFalse(isValid, "Price of 0 should fail validation");
    }
    
    /**
     * Additional Test: ValidateData_InvalidPercentage
     * 
     * Tests that ValidateData correctly rejects form data when 
     * the Commission Percentage is zero or negative.
     * 
     * Validation Rule Being Tested: Commission Percentage must be > 0
     * 
     * This ensures commission cannot be zero or negative.
     */
    @Test
    public void ValidateData_InvalidPercentage() {
        // ARRANGE: Create data with invalid commission percentage
        EstateAgentQ2 agent = new EstateAgentQ2();
        Data testData = new Data();
        
        testData.setAgentLocation("Cape Town");
        testData.setAgentName("Joe Bloggs");
        testData.setPropertyPrice("800000");
        testData.setCommissionPercentage("-5");      // Invalid: must be > 0
        
        // ACT: Validate the data
        boolean isValid = agent.ValidateData(testData);
        
        // ASSERT: Verify validation fails for negative percentage
        assertFalse(isValid, "Negative commission should fail validation");
    }
}