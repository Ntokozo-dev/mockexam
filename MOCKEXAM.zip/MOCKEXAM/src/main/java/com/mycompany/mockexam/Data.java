/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mockexam;

/**
 *
 * @author ntokozomtsali
 */
public class Data {
  private  String agentLocation;
  private String agentName;
  private String propertyPrice;
  private String commissionPercentage;
  //constructor
  public Data (){
     this.agentLocation = "";
        this.agentName = "";
        this.propertyPrice = "";
        this.commissionPercentage = "";  
  }
    
  public String getAgentLocation(){
      return agentLocation;
  } 
  public String getAgentName(){
      return agentName;
  }
  public String getPropertyPrice(){
      return propertyPrice;
  }
  public String getPercentage(){
     return commissionPercentage;  
  }
   public void setAgentLocation (String agentLocation) {
      this.agentLocation = agentLocation;  
  } 
  public void setAgentName (String agentName){
      this .agentName = agentName;
  }
  public void setPropertyPrice (String propertyPrice){
      this .propertyPrice = propertyPrice;
  }
  public void setCommissionPercentage (String commissionPercentage){
      this .commissionPercentage = commissionPercentage;
}
}