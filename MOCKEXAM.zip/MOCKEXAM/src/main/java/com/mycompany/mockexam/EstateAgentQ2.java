package com.mycompany.mockexam;

public class EstateAgentQ2 implements IEstateAgentQ2 {
    
    @Override
    public double CalculateCommission(String propertyPrice, String agentCommission) {
        double price = Double.parseDouble(propertyPrice);
        double percentage = Double.parseDouble(agentCommission);
        return price * (percentage / 100.0);
    }
    
    @Override
    public boolean ValidateData(Data dataToValidate) {
        if (dataToValidate == null) {
            return false;
        }
        
        // Location validation
        String location = dataToValidate.getAgentLocation();
        if (location == null || location.trim().isEmpty()) {
            return false;
        }
        
        // Name validation
        String name = dataToValidate.getAgentName();
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        
        // Price validation
        try {
            double price = Double.parseDouble(dataToValidate.getPropertyPrice());
            if (price <= 0) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        
        // Percentage validation
        try {
            double percentage = Double.parseDouble(dataToValidate.getPercentage());
            if (percentage <= 0) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        
        return true;
    }
}