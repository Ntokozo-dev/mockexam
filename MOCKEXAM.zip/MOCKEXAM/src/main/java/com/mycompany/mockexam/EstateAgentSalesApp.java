/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mockexam;

/**
 *
 * @author ntokozomtsali
 */
public class EstateAgentSalesApp {
      public static void main(String[] args) {
        // an array containing the sales made by the two agents
        double[][] monthlySales = {
            {800000, 1500000, 2000000},  // Joe Bloggs
            {700000, 1200000, 1600000}   // Jane Doe
        };
        
        //an object to call estate agent methods
        EstateAgent agent = new EstateAgent();
        
        // Calls for  EstateAgentSales for Joe (row 0)
        double joeTotal = agent.EstateAgentSales(monthlySales[0]);
        System.out.println("Joe's total sales: " + joeTotal);
        
        // Step 4: Do the same for Jane
        double janeTotal = agent.EstateAgentSales(monthlySales[1]);
        System.out.println("Jane's total sales: "+ janeTotal);
        
        //Calculate commissions
        double joeCommission = agent.EstateAgentCommission(joeTotal);
        double janeCommission = agent.EstateAgentCommission(janeTotal);
        System.out.println("Joe's commission: " + joeCommission);
        System.out.println("Jane's commission: " + janeCommission);
        
        // Step 6: Find top agent
        double[] totals = {joeTotal, janeTotal};
        int topAgent = agent.TopEstateAgent(totals);

        if (topAgent == 0) {
        System.out.println("Top performing agent: Joe Bloggs");
}       else {
        System.out.println("Top performing agent: Jane Doe");
}
}
    }  

