/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.mockexam;

/**
 *
 * @author ntokozomtsali
 */
public interface IEstateAgent {
    /**
     * takes an array of monthly property sales figures and calculates the total sum
     * @param propertySales array of sales amounts
     * @return total sum of all sales
     */
    double EstateAgentSales (double[] propertySales);
    /**
    * 
    * @param propertySales total property sales amount
    * @return 2% portion of the total sale
    */
    double EstateAgentCommission(double propertySales);

  /**
    * 
    * @param totalSales
    * @return the greater sales between index o and 1
    */
    int TopEstateAgent (double[] totalSales);
}  

