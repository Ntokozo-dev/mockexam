package com.mycompany.mockexam;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Main GUI application for calculating estate agent commissions.
 * Uses Swing components (JFrame, JComboBox, JTextField, JTextArea, JMenu).
 * Features: form input, data validation, commission calculation, file saving.
 */
public class EstateAgentGUI extends JFrame {
    
    // GUI Components
    private JComboBox<String> locationCombo;
    private JTextField agentNameField;
    private JTextField propertyPriceField;
    private JTextField commissionPercentageField;
    private JTextArea reportArea;
    
    // Business logic
    private EstateAgentQ2 agent;
    private Data formData;
    
    //Constructor - Sets up the GUI window and all components.
    
    public EstateAgentGUI() {
        // Initialize business objects
        agent = new EstateAgentQ2();
        formData = new Data();
        
        // Set window properties
        setTitle("Estate Agent Report");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create menu bar
        createMenuBar();
        
        // Create main panel with form
        createFormPanel();
        
        // Make window visible
        setVisible(true);
    }
    
    // Creates the menu bar with File and Tools menus
    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // FILE MENU
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));  // Exit program
        fileMenu.add(exitItem);
        
        // TOOLS MENU
        JMenu toolsMenu = new JMenu("Tools");
        
        // Process Report menu item
        JMenuItem processItem = new JMenuItem("Process Report");
        processItem.addActionListener(e -> processReport());
        toolsMenu.add(processItem);
        
        // Clear menu item
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());
        toolsMenu.add(clearItem);
        
        // Save Report menu item
        JMenuItem saveItem = new JMenuItem("Save Report");
        saveItem.addActionListener(e -> saveReport());
        toolsMenu.add(saveItem);
        
        // Add menus to menu bar
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);
    }
    
    //Creates the form panel with input fields and text area.
   
    private void createFormPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Row 1: Agent Location Label and Combo Box
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("AGENT LOCATION:"), gbc);
        
        gbc.gridx = 1;
        String[] locations = {"Cape Town", "Durban", "Pretoria"};
        locationCombo = new JComboBox<>(locations);
        panel.add(locationCombo, gbc);
        
        // Row 2: Agent Name Label and Text Field
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("ESTATE AGENT NAME:"), gbc);
        
        gbc.gridx = 1;
        agentNameField = new JTextField(15);
        panel.add(agentNameField, gbc);
        
        // Row 3: Property Price Label and Text Field
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("PROPERTY PRICE:"), gbc);
        
        gbc.gridx = 1;
        propertyPriceField = new JTextField(15);
        panel.add(propertyPriceField, gbc);
        
        // Row 4: Commission Percentage Label and Text Field
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("COMMISSION PERCENTAGE:"), gbc);
        
        gbc.gridx = 1;
        commissionPercentageField = new JTextField(15);
        panel.add(commissionPercentageField, gbc);
        
        // Row 5: Report Label
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("ESTATE AGENT REPORT:"), gbc);
        
        // Row 6: Report Text Area (spans 2 columns)
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1.0;
        gbc.weighty = 1.0;
        reportArea = new JTextArea(10, 40);
        reportArea.setEditable(false);
        reportArea.setLineWrap(true);
        reportArea.setWrapStyleWord(true);
        
        JScrollPane scrollPane = new JScrollPane(reportArea);
        panel.add(scrollPane, gbc);
        
        add(panel);
    }
    
    //Processes the report when user clicks "Process Report".
   
    private void processReport() {
        // Step 1: Collect data from form fields
        formData.setAgentLocation((String) locationCombo.getSelectedItem());
        formData.setAgentName(agentNameField.getText());
        formData.setPropertyPrice(propertyPriceField.getText());
        formData.setCommissionPercentage(commissionPercentageField.getText());
        
        // Step 2: Validate the data
        if (!agent.ValidateData(formData)) {
            JOptionPane.showMessageDialog(this, 
                "Invalid input! Check that:\n" +
                "- Location is selected\n" +
                "- Name is not empty\n" +
                "- Price > 0\n" +
                "- Commission % > 0",
                "Validation Error", 
                JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Step 3: Calculate commission
        try {
            double commission = agent.CalculateCommission(
                formData.getPropertyPrice(),
                formData.getPercentage()
            );
            
            // Step 4: Display the report
            String report = String.format(
                "AGENT LOCATION: %s\n" +
                "AGENT NAME: %s\n" +
                "PROPERTY PRICE: R %s\n" +
                "COMMISSION PERCENTAGE: %s%%\n" +
                "CALCULATED COMMISSION: R %.1f",
                formData.getAgentLocation(),
                formData.getAgentName(),
                formData.getPropertyPrice(),
                formData.getPercentage(),
                commission
            );
            reportArea.setText(report);
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, 
                "Error calculating commission. Invalid number format.",
                "Calculation Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //Clears all form fields and report area.
    
    private void clearForm() {
        locationCombo.setSelectedIndex(0);
        agentNameField.setText("");
        propertyPriceField.setText("");
        commissionPercentageField.setText("");
        reportArea.setText("");
    }
    
    /**
     * Saves the report to a file named "report.txt".
     * If no report is displayed, nothing is saved.
     */
    private void saveReport() {
        String reportText = reportArea.getText();
        
        // Check if report is empty
        if (reportText.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "No report to save. Process a report first.",
                "Save Error", 
                JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        // Write to file
        try {
            FileWriter writer = new FileWriter("report.txt");
            writer.write("ESTATE AGENT REPORT\n");
            writer.write("*".repeat(40) + "\n");
            writer.write(reportText);
            writer.write("\n" + "*".repeat(40));
            writer.close();
            
            JOptionPane.showMessageDialog(this, 
                "Report saved to report.txt",
                "Save Successful", 
                JOptionPane.INFORMATION_MESSAGE);
                
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, 
                "Error saving file: " + e.getMessage(),
                "File Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }
    
    //Main method to launch the application.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EstateAgentGUI());
    }
}
