/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mockexam;

/**
 *
 * Implements the IEstateAgent interface and provides methods
 * to calculate total sales, commission earned, and determine
 * the top-performing estate agent.
 *
 * @author ntokozomtsali
 */
public class EstateAgent implements IEstateAgent{
    @Override
    public double EstateAgentSales (double[] propertySales){
      double total = 0;
       // Loop through the sales array and add each sale to the total
for (int i = 0; i < propertySales.length; i++) {
    total = total + propertySales[i]; 
}
// Return the total sales amount
return total;  
    }
    @Override
    public double EstateAgentCommission(double propertySales){
         double commission = propertySales * 0.02;
         
         return commission;
    }
    @Override
       //Determines which estate agent achieved the highest sales.
    
    public int TopEstateAgent (double[] totalSales){
        
        // Compare the sales totals of the first two agents
       if (totalSales[0] > totalSales[1]) {
    return 0;  // Joe (index 0) has more sales
} else {
    return 1;  // Jane (index 1) has more sales
}
}  

}  

