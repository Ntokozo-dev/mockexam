/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.mockexam;

/**
 *
 * @author ntokozomtsali
 */
public interface IEstateAgentQ2 {
    
 /**
     * calculate 2% of the property price
     * @param propertyPrice property price as a string
     * @param agentCommission commission percentage as a string
     * @return the calculated commission
     */
    double CalculateCommission(String propertyPrice, String agentCommission);
    
    /**
     * validate the user input/data 
     * @param dataToValidate the Data object containing form values
     * @return true if valid, false if invalid
     */
    boolean ValidateData(Data dataToValidate);
}
